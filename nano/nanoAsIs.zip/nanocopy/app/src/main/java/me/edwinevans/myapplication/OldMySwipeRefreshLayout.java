//TODO!!! Delete

package me.edwinevans.myapplication;

import android.content.Context;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.AttributeSet;
import android.view.View;

public class OldMySwipeRefreshLayout extends SwipeRefreshLayout {
    private View mScrollingView;

    public OldMySwipeRefreshLayout(Context context) {
        super(context);
    }

    public OldMySwipeRefreshLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean canChildScrollUp() {
        return mScrollingView != null && ViewCompat.canScrollVertically(mScrollingView, -1);
    }

    public void setScrollingView(View scrollingView) {
        mScrollingView = scrollingView;
    }
}