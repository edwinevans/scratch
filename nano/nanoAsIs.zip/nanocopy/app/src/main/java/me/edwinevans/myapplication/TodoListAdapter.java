package me.edwinevans.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class TodoListAdapter extends ArrayAdapter<String>
{
    private Activity mActivity = null;
    private int mResource;
    private LayoutInflater mLayoutInflater;
    private List<String> mItems = new ArrayList<>();

    public TodoListAdapter(Activity activity, int resource)
    {
        super(activity, resource);
        mActivity = activity;
        mResource = resource;
        mLayoutInflater = (LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void addItem(@NonNull String item)
    {
        mItems.add(item);
        notifyDataSetChanged();
    }

    public void removeItem(@NonNull int position)
    {
        mItems.remove(position);
        notifyDataSetChanged();
    }

    @Override
    public int getCount()
    {
        return mItems.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewHolder holder;

        if (convertView == null)
        {
            convertView = mLayoutInflater.inflate(R.layout.list_item, null);
            holder = new ViewHolder();
            TextView tv = (TextView) convertView.findViewById(R.id.list_item_text);
            holder.itemTextView = tv;
            final int pos = position;
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mActivity, TodoItemActivity.class);
                    intent.putExtra(Constants.TODO_ITEM_INTENT_ITEM_ID, getItemId(pos));
                    //  intent.setData(new Uri)
                    mActivity.startActivityForResult(intent, Constants.ADD_ITEM_REQUEST_CODE);
                }
            });
            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }

        final String item = mItems.get(position);
        holder.itemTextView.setText(item);

        return convertView;
    }

    static class ViewHolder
    {
        CheckBox itemCheckbox;
        TextView itemTextView;
    }
}
