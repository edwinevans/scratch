package me.edwinevans.myapplication;

class Constants {
    public static final int ADD_ITEM_REQUEST_CODE = 1;
    public static final String ADD_ITEM_RESULT_KEY = "add_item_result";
    public static final String TODO_ITEM_INTENT_ITEM_ID = "item_id";
    public static final int RESULT_DELETE = 1;
}
