// Thanks
// https://github.com/onemonth/android-todo-list/tree/master/app/src/main/java/com/onemonth/todolist
// Maher - https://www.linkedin.com/in/maher-hanafi-003b6947/
// Stack Overflow

// Attempted: https://github.com/woxblom/DragListView/

package me.edwinevans.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TodoListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupTodoListSection();
        setupLauncherSection();
    }

    void setupTodoListSection() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startAddItemActivity();
            }
        });

        mAdapter = new TodoListAdapter(this, R.id.todo_list_item);
        mAdapter.addItem("Get Milk");
        mAdapter.addItem("Make reorderable");

        ListView listView = (ListView) findViewById(R.id.activity_main_listview);
        listView.setAdapter(mAdapter);
        registerForContextMenu(listView);

//        listView.setClickable(true);
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                handleItemClick(parent, view, position, id);
//
//            }
//        });
    }

    private void handleItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, TodoItemActivity.class);
        startActivityForResult(intent, Constants.ADD_ITEM_REQUEST_CODE);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);

        if (v.getId() == R.id.activity_main_listview)
        {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu_main, menu);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int position = info.position;
        mAdapter.removeItem(position);

        return true;
    }

    private void startAddItemActivity()
    {
        Intent intent = new Intent(this, TodoItemActivity.class);
        startActivityForResult(intent, Constants.ADD_ITEM_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.ADD_ITEM_REQUEST_CODE)
        {
            if (resultCode == RESULT_OK)
            {
                String item = data.getStringExtra(Constants.ADD_ITEM_RESULT_KEY);
                mAdapter.addItem(item);
            }
//            else if (resultCode == RESULT_DELETE) {
//
//            }
        }
    }

    void setupLauncherSection() {
        GridView gridView = (GridView) findViewById(R.id.launcher_grid);
        gridView.setAdapter(new LauncherGridAdapter(this));

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {


                Toast.makeText(MainActivity.this, "" + position,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
