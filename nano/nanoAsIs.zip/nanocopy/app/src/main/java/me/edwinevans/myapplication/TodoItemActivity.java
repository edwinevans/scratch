package me.edwinevans.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


public class TodoItemActivity extends AppCompatActivity {
    EditText mEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_detail);
        mEditText = (EditText) findViewById(R.id.todo_edit_text);

        // wait... should use data
        //getIntent().getLongExtra(Constants.TODO_ITEM_INTENT_ITEM_ID)

        findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveItem();
            }
        });

        findViewById(R.id.delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem();
            }
        });
    }

    private void deleteItem() {
        Intent intent = new Intent();
        setResult(Constants.RESULT_DELETE, intent);
        finish();
    }

    private void saveItem()
    {
        Intent intent = new Intent();
        String item = mEditText.getText().toString();

        if (item.length() == 0)
        {
            setResult(RESULT_CANCELED, intent);
        }
        else
        {
            intent.putExtra(Constants.ADD_ITEM_RESULT_KEY, item);
            setResult(RESULT_OK, intent);
        }

        finish();
    }
}
