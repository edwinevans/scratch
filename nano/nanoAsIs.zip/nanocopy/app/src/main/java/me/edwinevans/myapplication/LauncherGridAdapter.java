package me.edwinevans.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class LauncherGridAdapter extends BaseAdapter {
    private final PackageManager mPackageManager;
    private Context mContext;
    List<ResolveInfo> mAppsList;

    public LauncherGridAdapter(Context c) {
        mContext = c;
        mPackageManager = mContext.getPackageManager();

        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        mAppsList = mPackageManager.queryIntentActivities( mainIntent, 0);

    }

    public int getCount() {
        return mAppsList.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)mContext.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
        View view;
        if (convertView == null) {
            view = inflater.inflate(R.layout.launcher_grid_item, parent, false);
            view = view.findViewById(R.id.launcher_grid_view_container);
        } else {
            view = convertView;
        }

        ResolveInfo resolveInfo = mAppsList.get(position);
        String appName = resolveInfo.loadLabel(mPackageManager).toString();
        Drawable icon = resolveInfo.loadIcon(mPackageManager);

        ImageView imageView = (ImageView)view.findViewById(R.id.app_icon);
        if (icon != null) {
            try {
                imageView.setImageDrawable(icon);
            }
            catch (Exception e) {
                //test
                e.printStackTrace();
            }
        }

        TextView textView = (TextView)view.findViewById(R.id.app_label);
        textView.setText(appName);

        return view; // TODO!!!
    }
}